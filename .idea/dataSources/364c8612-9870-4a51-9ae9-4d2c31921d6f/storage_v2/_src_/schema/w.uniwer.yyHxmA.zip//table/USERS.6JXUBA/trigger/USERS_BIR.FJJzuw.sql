create trigger USERS_BIR
    before insert
    on USERS
    for each row
BEGIN
    -- Если Java ПЕРЕДАЛА id, триггер ничего не делает
    IF :new.user_id IS NULL THEN
        SELECT users_seq.NEXTVAL INTO :new.user_id FROM dual;
    END IF;
END;
/

