create trigger CLIENT_PROF_BIR
    before insert
    on CLIENT_PROFILES
    for each row
BEGIN
  IF :new.profile_id IS NULL THEN
    SELECT client_prof_seq.NEXTVAL INTO :new.profile_id FROM dual;
  END IF;
END;
/

